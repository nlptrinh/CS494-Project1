## HCMUS-CS494-Internet-SocketProject

### Participants:
	1751012 - Nguyen Chan Nam	- Leader
	1751054 - Long Vu Quynh Chau	- Mvp
	1751078 - Nguyen Vo Duc Loc	- Culi

### Run server:
	src.server.MainServer

### Run client (multiple times, depends on number of players setting):
	src.client.MainClient
	
### Setting:
	In MainServer.java, modify these variables:
		maxNumPlayers
		maxNumQuestions
