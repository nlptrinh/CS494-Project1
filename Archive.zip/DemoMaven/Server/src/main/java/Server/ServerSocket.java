package main.java.Server;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class ServerSocket {
    public final static int SERVER_PORT = 7;
    {
        java.net.ServerSocket serverSocket = null;
        try {
            System.out.println("Binding to port " + SERVER_PORT + ", please wait  ...");
            serverSocket = new java.net.ServerSocket(SERVER_PORT);
            System.out.println("Server started: " + serverSocket);
            System.out.println("Waiting for a client ...");
            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    System.out.println("Client accepted: " + socket);

                    OutputStream os = socket.getOutputStream();
                    InputStream is = socket.getInputStream();


                    // Handle messsage object

//                    int ch = 0;
//                    while (true) {
//                        ch = is.read(); // Receive data from client
//                        if (ch ==-1) {
//                            break;
//                        }
//                        os.write(ch+1); // Send the results to client
//                    }
//                    socket.close();
                    while(true){
                        String msg = (String)ois.readObject();
                        ServerMessage sm;
                        try {
                            sm = Helper.unmarshall(msg);
                        } catch (JAXBException e) {
                            e.printStackTrace();
                            continue;
                        }
                        switch(sm.messageType){
                            case GET_ID:
                                oos.writeLong(main.getId());
                                break;
                            case GET_MAP:
                                try {
                                    String data = Helper.marshall(main.getMap());
                                    oos.writeObject(data);
                                } catch (JAXBException e) {
                                    e.printStackTrace();
                                }
                                break;
                            case SEND_MAIN_CHARACTER:
                                main.includeCharacter(sm.characterData);
                                break;
                            case GET_ID_IP_PORT:
                                String ipString = socket.getInetAddress().getHostName();
                                InetAddress clientIp = InetAddress.getByName(ipString);
                                System.err.println(ipString + " " + clientIp);
                                main.addressBook(clientIp, sm.port);
                                break;
                            case REMOVE_CHARACTER:
                                main.removeCharacter(sm.id);
                                break;
                            default:
                                break;
                        }
                        oos.flush();

                    }

                } catch (IOException e) {
                    System.err.println(" Connection Error: " + e);
                }
            }
        } catch (IOException e1) {
            e1.printStackTrace();
        } finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
